Gull sounds with background noise removed.

Licensing:
  - Creative Commons Attribution-ShareAlike (CC BY-SA) 3.0

Source:
  - By Jonathon Jongsma: https://www.xeno-canto.org/75111
